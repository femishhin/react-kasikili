
import React from 'react'; 
import MainLayout from '../layout/Mainlayout'; 

function Dashboard() {
  return (
    <MainLayout>
      <div>
        Dashboard          
      </div>
    </MainLayout> 
  );
}

export default Dashboard;
